package vehicle;
import java.util.Scanner;
public class ArrayExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int a[]=new int[10];
			a[1]=2;
			Scanner sc=new Scanner(System.in);
			String x=sc.next();
			int i=Integer.parseInt(x);
			a[i]=9;
			System.out.println(x);
			System.out .println(a[i]);
			String s=null;
			System.out.println(s.length());
			    
		}catch(NumberFormatException e)
		{
			System.out.println("no integer input");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.err.println("array index is out of bound" + e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.err.println("null value");
		}
		finally
		{
			System.out.println("Done with Exceptions");
		}
	}

}

