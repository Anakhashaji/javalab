package vehicle;
interface MusicalInstrument
{
	public void play();
	public String getDescription();
	public float getPrice();
	
}



interface StringInstr extends MusicalInstrument
{
	public int getNoOFString();
}


interface Precurssion extends MusicalInstrument
{
	public String gettype();
}

class Violin implements StringInstr

{
	public void play()
	{
		System.out.println("Violin play");
	}
	
	public String getDescription()
	{
		return "This a violin";
	}
	
	public float getPrice()
	{
		float a=100;
		return a;
	}
	
	
	public int getNoOFString()
	{
		return 4;
	}
}


class Tabla implements Precurssion
{
	public  String gettype() 
	{
		return "aaa";
	}
	
	public void play()
	{
		System.out.println("Tabla play");
	}
	
	public String getDescription()
	{
		return "This a tabla";
	}
	
	public float getPrice()
	{
		float a=500;
		return a;
	}
		
	

}

class Students 
{
	String name;
	MusicalInstrument ownmlinstr;
	Students (String n,MusicalInstrument o)
	{
		name=n;
		ownmlinstr=o;
		
	}
	public void play()
	{
		ownmlinstr.play();
		String s=ownmlinstr.getDescription();
		System.out.println(s);
		float f=ownmlinstr.getPrice();
		System.out.println(f);

	}
}
public class music {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Students obj=new Students("aa",new Tabla());
			obj.play();
			

	}

}

