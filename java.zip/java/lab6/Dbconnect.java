
import java.sql.*;
public class Dbconnect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String databaseURL = "jdbc:ucanaccess://C:\\Users\\hp\\Desktop\\Database.accdb";

	     try (Connection connection = DriverManager.getConnection(databaseURL)) {
	    	    String sql = "INSERT INTO db1 (id,Add,Name) VALUES (?, ?, ?)";
	             
	            PreparedStatement preparedStatement = connection.prepareStatement(sql);
	            preparedStatement.setInt(1, 1);
	            preparedStatement.setString(2, "klm");
	            preparedStatement.setString(3, "aiswarya");
	             
	            int row = preparedStatement.executeUpdate();
	             
	            if (row > 0) {
	                System.out.println("A row has been inserted successfully.");
	            }
	             
	            sql = "SELECT * FROM db1";
	             
	            Statement statement = connection.createStatement();
	            ResultSet result = statement.executeQuery(sql);
	             
	            while (result.next()) {
	                int id = result.getInt("id");
	                String address = result.getString("Add");
	                String name = result.getString("Name");
	               
	                 
	                System.out.println(id+ ", " + address + ", " + name);
	            }
	             
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	        }
        		 
	}


	             
	             
	

	


