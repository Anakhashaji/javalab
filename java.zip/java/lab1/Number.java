import java.util.Scanner;
public class Number {
	
	
	static void sod(int m)
	{
		int n=0,sum=0;
        while(m > 0)

        {
            n = m % 10;
            sum = sum + n;
            m = m / 10;
        }

        System.out.println("Sum of Digits:"+sum);
	}
	
	static void largest(int n)
	{
		int largest = 0; 
	    while(n != 0)  
	    { 
	        int r = n % 10; 
	        largest = Math.max(r, largest); 
	        n = n / 10; 
	    } 
	    System.out.println(largest); 
	}
	
	static void reverse(int n)
	{
		int reverse=0;
		while(n != 0)
	      {
	          reverse = reverse * 10;
	          reverse = reverse + n%10;
	          n = n/10;
	      }
	       
	      System.out.println("Reverse of the number is " + reverse);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		//read();
		sod(x);
		largest(x);
		reverse(x);

	}

}
