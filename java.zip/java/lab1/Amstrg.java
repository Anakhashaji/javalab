
public class Amstrg {
	 static void armstrong( int num)
		{
			 	int n=num;
			 
	            int res=0,remainder;
	 
	            while(num > 0){
	 
	                remainder = num % 10;
	 
	 
	                res = res + (remainder*remainder*remainder);
	 
	                num = num / 10;
	 
	            }
	 
	            if(res == n)
	 
	                System.out.println(n+" is an Armstrong Number");
	 
	            else
	 
	                System.out.println(n+" is not a Armstrong Number");
	 
		}
	 static void perfect(int num)
	 {
		 int perfectNo = 0;               
      int i;             
      System.out.println("Factors are:"); 
      for (i = 1; i < num; i++) {           
          if (num % i == 0) {                              
              perfectNo += i;           
              System.out.println(i);  
          }         
      }            
      if (perfectNo == num) {  
          System.out.println("number is a perfect number");         
      }
      else
      {                      
          System.out.println("number is not a perfect number");    
      }       
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		armstrong(153);
		perfect(643);


	}

}
