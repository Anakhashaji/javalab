import java.util.Scanner;
public class power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		    int n,p,result=1;
			 Scanner input = new Scanner(System.in);
			 System.out.print("Input n: ");
	          n = input.nextInt();
	         System.out.print("Input p: ");
	          p = input.nextInt();
		    if(n>=0&&p==0)
		     {
		        result=1;
		     }
		    else if(n==0&&p>=1)
		      { 
		         result=0;
		      }
		    else
		     {
		         for(int i=1;i<=p;i++)
			 {
		            result=result*n;
		 	 }	    
		     }
		    System.out.println(n+"^"+p+"="+result);
			
		 

	}

}
