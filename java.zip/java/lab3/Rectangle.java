
package rectangle;


 class abc {
    
  
	protected int length;
	protected int width;
	 int a;
	public abc(int l,int w)
	{
		 length=l;
		 width=w;
	}
		public int area()
		{
			 a=length*width;
			 return a;
		}
		
}
class box extends abc
{
	public int depth;

public box(int l,int w,int d)
{
	super(l,w);
	depth=d;
}
public int volume()
{
	int v=length*width*depth;
	return v;
}
}

    /**
     * @param args the command line arguments
     */
public class Rectangle
{
    public static void main(String[] args) {
        // TODO code application logic here
    
    

	
		abc r=new abc(2,4);
		int ar=r.area();
		box b1=new box(3,4,5);
		int c=b1.volume();
			System.out.println(ar);
			System.out.println(c);

	}

}

