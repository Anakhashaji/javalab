package rectangle;


import java.util.*;

public class bbbb {

	public static void main(String[] args) {
	
		Bankacnt b= new Bankacnt("sruuu",1111,"TSR","Savings",1000);
		b.display();
		Bankacnt b1= new Bankacnt();
		b1.read();
		b.deposit(5000);
		b.withdraw(500); 
	}

}
class Bankacnt
{
	private String dname;
	private int accno;
	private String add;
	private String type;
	private int bal;
	public void read()
	{
       Scanner sc= new Scanner(System.in);
       dname=sc.next();
       add= sc.next();
       type=sc.next();
       accno=sc.nextInt();
     }
	
	public void deposit(int d)
	{
		  this.bal+=d;
	}
	public void withdraw(int w)
	{
	    this.bal-=w;
    }
	public void display()
	{
		System.out.println("Name: "+dname);
		System.out.println("AccountNo: "+accno);
		System.out.println("Address: "+add);
		System.out.println("AccntType: "+type);
		System.out.println("Balance: "+bal);
	}
	public Bankacnt(String dname,int accno,String add,String type,int bal)
	{
	this.dname=dname;
	this.accno=accno;
	this.add=add;
	this.type=type;
	this.bal=bal;
	}
	public Bankacnt()
	{
		dname="Anjali";
		accno=444;
		add="KSD";
		type="Savings";
		bal=4000;
		
	}
	}


