import java.util.ArrayList;
import java.util.List;

class Book {
    String title, author;
    int year;
    public Book(String title, String author, int year) {
        this.title = title;
        this.author = author;
        this.year = year;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public int getYear() {
        return year;
    }
    public String toString() {
        return "Title of the book:" + this.title+"\nAuthor:"+ this.author + "\nYear:" + this.year;
    }
   
}

class BookList{
    private List<Book> list;
   
    public BookList(ArrayList<Book> obj) {
        list = obj;
        System.out.println(list.size());
    }
    public boolean addBook(Book book) {
        list.add(book);
        return true;
    }
    public boolean delBook(Book book) {
        list.remove(book);
        return true;
    }
   
    public void printList() {
        for(int i=0; i < list.size();i++) {
            System.out.println(list.get(i));
        }
    }
    public void PrintTitlesByAuthor(String Author) {
        for(int i=0; i < list.size();i++) {
//            System.out.println(list.get(i).author);
            if(list.get(i).author.equals(Author)) {
                System.out.println(list.get(i).title);
            }
               
           
        }
       
    }
   
    public void PrintBooksInYears(int firstYear, int lastYear) {
        for(int i=0; i < list.size();i++) {
//            System.out.println(list.get(i).author);
            if(list.get(i).year> firstYear && list.get(i).year < lastYear) {
                System.out.println(list.get(i).title);
            }
               
           
        }
    }
   
}
public class books {
    public static void main(String[] args) {
        ArrayList<Book> booklist = new ArrayList<Book>(5);
        Book book1 = new Book("book1","author1", 1999);
        Book book2 = new Book("Book2","author2", 1999);
//        System.out.println(obj.getAuthor());
        booklist.add(book1);
        booklist.add(book2);
       
        Book book3 = new Book("book3 ","author3", 2000);
       
        BookList books = new BookList(booklist);
        books.addBook(book3);
//        books.printList();
       
        books.delBook(book2);
//        books.printList();
        books.PrintTitlesByAuthor("author3");
        books.PrintBooksInYears(1990, 2000);
       
       
    }
}
