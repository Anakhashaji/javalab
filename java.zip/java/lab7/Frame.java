import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.*;

import javax.swing.*;
public class Frame 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		JFrame f = new JFrame("registration form");
		JLabel name=new JLabel("NAME");
		JLabel Rollno=new JLabel("ROLL NO");
		JLabel Gender=new JLabel("GENDER");
		JLabel Course=new JLabel("COURSE");
		JLabel batch=new JLabel("BATCH");
		JTextField t1=new JTextField(15);
		JTextField t2=new JTextField(15);
		JTextField t3=new JTextField(15);
		JTextField t4=new JTextField(15);
		JTextField t5=new JTextField(15);
		JRadioButton j1 = new JRadioButton(); 
		JRadioButton j2 = new JRadioButton(); 
		j1.setText("male"); 
		j2.setText("female"); 
		FlowLayout f1=new FlowLayout();
		f.setLayout(f1);
		f.add(name);
		f.add(t1);
		f.add(Rollno);
		f.add(t2);
		f.add(Gender);
		f.add(j1);
		f.add(j2);
		f.add(Course);
		f.add(t4);
		f.add(batch);
		f.add(t5);
		
		JButton button=new JButton("SUBMIT");
		JButton button1=new JButton("CANCEL");
		f.getContentPane().add(button);
		f.getContentPane().add(button1);
        
		
		
		f.setVisible(true);
		f.setSize(500,500);
		f.getContentPane().add(button1);
		 button.addActionListener(new EventHandler(t1,t2,t3,t4,t5));
		 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
		 }

		}

		class EventHandler implements ActionListener{
		JTextField jt1,jt2,jt3,jt4,jt5;
		public EventHandler(JTextField f1,JTextField f2,JTextField f3,JTextField f4,JTextField f5)
		{
		 jt1=f1;
		 jt2=f2;
		 jt3=f3;
		 jt4=f4;
		 jt5=f5;
		}
		
	
		public void actionPerformed(ActionEvent ar)
		{
			 String databaseURL = "jdbc:ucanaccess:C:\\Users\\hp\\Desktop\\Database4.accdb";

		     try (Connection connection = DriverManager.getConnection(databaseURL)) {
		    	    String sql = "INSERT INTO db1 (id,Add,Name) VALUES (?, ?, ?)";
		             
		            PreparedStatement preparedStatement = connection.prepareStatement(sql);
		            preparedStatement.setInt(1, 1);
		            preparedStatement.setString(2, "klm");
		            preparedStatement.setString(3, "aiswarya");
		             
		            int row = preparedStatement.executeUpdate();
		             
		            if (row > 0) {
		                System.out.println("A row has been inserted successfully.");
		            }
		     }
		     
		

		     catch(Exception exp)
	            {
	             System.out.print(exp);
	            }
	       
	        }
	}


