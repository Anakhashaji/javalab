package socket;

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 1234;
        String hostname = "localhost";
        Scanner sc = new Scanner(System.in);
        try{
            Socket socket = new Socket(hostname, port);

            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            System.out.println("Enter the first number: ");
            int x= sc.nextInt();

            System.out.println("Enter the second number: ");
            int y= sc.nextInt();

            out.writeInt(x);
            out.writeInt(y);

            DataInputStream  in = new DataInputStream(socket.getInputStream());

            int sum = in.readInt();
            System.out.println("The sum of two numbers is: "+ sum);
            sc.close();
            socket.close();
        }catch(IOException e)
        {
            System.err.println(e.getMessage());
        }
	}

}
