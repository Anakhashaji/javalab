package socket;
import java.net.*;
import java.io.*;
public class C_socket {
	public static void main(String[] args) {
        
	      
		 
	       // String hostName = null;
			String hostName="127.0.0.1";
	        int portNumber = 5554;
	      /* try {
	    	    System.out.println("requesting");
	        	Socket S = new Socket(hostName, portNumber);
	        }catch(Exception e) {System.out.println(e);}*/
	 
	      try (
	      Socket S = new Socket(hostName, portNumber);
	      PrintWriter out = new PrintWriter(S.getOutputStream(),true);
	      BufferedReader in =new BufferedReader(new InputStreamReader
	    		  (S.getInputStream()));
	      BufferedReader stdIn = new BufferedReader
	    		  (new InputStreamReader(System.in))
	        ) {
	            String userInput;
	            while ((userInput = stdIn.readLine()) != null) {
	                out.println(userInput);
	                System.out.println( in.readLine());
	            }
	        } catch (UnknownHostException e) {
	            System.err.println(" Don't know about host " + hostName);
	            System.exit(1);
	        } catch (IOException e) {
	            System.err.println("Couldn't get I/O for the connection to " +
	                hostName);
	            System.exit(1);
	        } 
	    }

	}






