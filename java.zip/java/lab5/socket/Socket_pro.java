package socket;
import java.net.*;
import java.util.Date;
import java.io.*;
public class Socket_pro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*try {
		
		ServerSocket serverSocket =  new ServerSocket(5554);
    	Socket clientSocket = serverSocket.accept();  
    	System.out.println(clientSocket.getPort());
		System.out.println(clientSocket.getInetAddress().getHostAddress());	
    	
	}catch(Exception e) {System.out.println(e);}*/
	
	try (
            ServerSocket serverSocket =  new ServerSocket(5554);
        	Socket clientSocket = serverSocket.accept();  
        	PrintWriter out =new PrintWriter 
        			(clientSocket.getOutputStream(), true);                   
            
        	BufferedReader in = new BufferedReader
        			(new InputStreamReader
        	(clientSocket.getInputStream()));
        ) {
			System.out.println(clientSocket.getPort());
    		System.out.println(clientSocket.getInetAddress().getHostAddress());	
            String inputLine;
            while ((inputLine = in.readLine())!= null) {
            	if(inputLine.equals("quit")) {
            		out.println("bye");break;
            	}
            	else if(inputLine.equals("time")) {
            		out.println("from server "+new Date().toString());
               
            		}
            	else if(inputLine.equals("kerala"))
            	{
            		out.println(" from server tvm");
            	}
            	else {
            		out.println("don't know");
            	}
            
            }
        } catch (IOException e) {
            
            System.out.println(e.getMessage());
        }
        System.out.println("server exiting");

	}

}








