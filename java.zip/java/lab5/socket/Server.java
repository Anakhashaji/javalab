package socket;

import java.net.*;
import java.io.*;
//import java.util.Scanner;

public class Server {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  try{

              ServerSocket serverSocket = new ServerSocket(1234);

              while(true){
                  
                  Socket s = serverSocket.accept();
                  try{
                  
                  DataInputStream  in = 
                          new DataInputStream(s.getInputStream());

                  int x = in.readInt();
                  int y = in.readInt();

                  int sum = ( x + y );
                  DataOutputStream out = new DataOutputStream(s.getOutputStream());
                  out.writeInt(sum);
                  serverSocket.close();
               }catch(SocketTimeoutException e)
               {
                  System.out.println("Socket timed out!");
                  break;
               }catch(IOException e)
               {
                  e.printStackTrace();
                  break;
               }
              }

      }catch(Exception e){
          System.err.println(e.getMessage());
      }
	}

}
