package threads;
class Mythread implements Runnable
{
	Thread t;
	public  Mythread()
	{
	t=new Thread(this,"mythread");
	t.start();
	
	}
	public Mythread(String n)
	{
		t=new Thread(this,n);
		t.start();
	}
	public void run()
	{
		System.out.println("thread"+t);
	}
}
public class Threadsamp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t=Thread.currentThread();
		System.out.println("current thread"+t);
		t.setName("main thread");
		System.out.println("after name change:"+t);
		Mythread obj= new Mythread("First Thread");
		Mythread obj1= new Mythread("Second Thread");
		try
		{
			for(int i=0;i<5;i++)
			{
 				System.out.println(i);
				Thread.sleep(1000);
			}
			
			}
		catch (InterruptedException e)
		{
			System.out.println("Main thread interrupted");
			}
			System.out.println("exiting main");
		}
	}
	


