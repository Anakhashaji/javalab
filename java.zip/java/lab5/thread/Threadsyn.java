package threads;

class SharedObj{
	
	public SharedObj() {}
	synchronized
	public void fn()  {
		try {
		for(int i=0;i<5;i++) {
			Thread.sleep(1000);
			System.out.println("i= "+i);
			
		}
		}catch(InterruptedException e) {System.out.println(e);}
	}
	
	
}
class Mythreads implements Runnable{
	Thread t;
	SharedObj ob;
	public Mythreads() {t=new Thread(this,"My thread");ob=null;
	t.start();}
	
	public Mythreads(String s,SharedObj o) 
	{t=new Thread(this,s);ob=o;
	t.start();}
	
	public void run() {
		System.out.println("in thread "+t);
		synchronized(ob) {
		ob.fn();
		}
	
		
	}
}

		public class Threadsyn {

			public static void main(String[] args) {
				// TODO Auto-generated method stub	
		
	
		SharedObj o=new SharedObj();
		Mythreads obj=new Mythreads("First Thread",o);
		Mythreads obj1=new Mythreads("Second Thread",o);
		
	
		try {
		obj.t.join();
		obj1.t.join();
		}catch(InterruptedException e) {System.out.println("Join interrupted");}
	
		System.out.println("exiting main");
		

	}

}

