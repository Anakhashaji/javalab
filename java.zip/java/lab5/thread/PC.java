package producer_consumer;
import java.util.LinkedList;
class Consumer implements Runnable{
	LinkedList<String>buff;
	int size;
	Thread t;
	
	public Consumer(LinkedList<String> b,int size) 
	{
		buff=b;
		this.size=size;
		t=new Thread(this,"Consumer");t.start();}
	
	 public String getItem() {
		 synchronized(buff){
		while(buff.size()==0) {
			try{System.out.println("consumer waiting");buff.wait();}catch(InterruptedException e) {e.printStackTrace();}
		}
			 
		System.out.println("consumer got signal");
		
		String s= buff.remove();
		buff.notify();
		
		System.out.println("removed "+s);
		try{Thread.sleep(10000);}catch(InterruptedException e) {System.out.println(e);}

		return s;
		}
	}
	public void run() {
		int i=0;
		while(i<10) {
		System.out.println(getItem());i++;
	}
}}
class Producer implements Runnable{
	LinkedList<String> buff;
	 int SIZE;
Thread t;
	
	public Producer(LinkedList<String> b, int s) 
	{buff=b;
	SIZE=s;
	t=new Thread(this,"Producer");t.start();}
	
	 public boolean putItem(String x) {
	synchronized(buff) {
		while(buff.size()>=SIZE) {
			try{System.out.println("producer waiting");buff.wait();}catch(InterruptedException e) {System.out.println(e);}
		}
		System.out.println("producer putting");
			buff.add(x);
			System.out.println("put"+x);
			System.out.println("notification by producer");
			buff.notify();
			try{Thread.sleep(5);}catch(InterruptedException e) {System.out.println(e);}
		}
			return true;
		}
	public void run() {
		int i=0;
	while(i<10) {
			putItem(new Integer(i++).toString());}
	}
	
	
}

public class PC {

	public static void main(String[] args) {
		
		LinkedList<String> a=new LinkedList<String>();
		
		Consumer c=new Consumer(a,5);
		Producer p=new Producer(a,5);
	   try { c.t.join();
	    p.t.join();}catch(InterruptedException e) {System.out.println(e);}
		

	}

}


